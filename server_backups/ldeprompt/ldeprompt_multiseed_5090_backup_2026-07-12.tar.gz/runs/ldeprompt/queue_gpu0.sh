#!/usr/bin/env bash
set -u

cd /workspace/BUPT/LDEPrompt
export CUDA_VISIBLE_DEVICES=0
export PYTHONUNBUFFERED=1

CURRENT_PID=3404
QUEUE_LOG=/workspace/runs/ldeprompt/queue_gpu0_master_$(date +%F_%H%M).log

echo "===== GPU0 queue started at $(date) =====" | tee -a "$QUEUE_LOG"
echo "Waiting for current PID $CURRENT_PID to finish..." | tee -a "$QUEUE_LOG"

while kill -0 "$CURRENT_PID" 2>/dev/null; do
  sleep 60
done

echo "Current PID $CURRENT_PID finished at $(date)" | tee -a "$QUEUE_LOG"

for SEED in 1997 1999 2001; do
  echo "===== Starting seed $SEED on GPU0 at $(date) =====" | tee -a "$QUEUE_LOG"
  LOG=/workspace/runs/ldeprompt/ldeprompt_cifar_b0inc10_seed${SEED}_$(date +%F_%H%M).log
  python -u main.py --config exps/cifar/ldeprompt_bupt_seed${SEED}.json 2>&1 | tee "$LOG"
  STATUS=${PIPESTATUS[0]}
  echo "===== Finished seed $SEED on GPU0 at $(date), status=$STATUS =====" | tee -a "$QUEUE_LOG"

  if [ "$STATUS" -ne 0 ]; then
    echo "Seed $SEED failed; stopping GPU0 queue." | tee -a "$QUEUE_LOG"
    exit "$STATUS"
  fi
done

echo "===== GPU0 queue completed at $(date) =====" | tee -a "$QUEUE_LOG"
